$(document).ready(function(){
    //navbar
    let nav_offset_top = $('.landing-photo').height() - 550;

    function navBarFixed()
    {
        if($('.landing-photo').length)
        {
            $(window).scroll(function(){
                let scroll = $(window).scrollTop();
                if(scroll >= nav_offset_top)
                {
                    $('.hd nav').addClass('navbar_fixed');
                    $('.hd nav a').removeClass('text-white')
                    $('.hd nav a').addClass('color-black');
                }
                else
                {
                    $('.hd nav').removeClass('navbar_fixed');
                    $('.hd nav a').removeClass('color-black');
                    $('.hd nav a').addClass('text-white');
                }
            })
        }
    }
    navBarFixed();

    //counter
    $(function(){
        $('#myFlipper').flipper('init');
    });

    //stellar
    $.stellar();

    //AOS Library
    AOS.init();

    //tilt.js
    VanillaTilt.init(document.querySelector(".gif-container"), {
		max: 10,
        speed: 400,
	});
	
	//It also supports NodeList
    VanillaTilt.init(document.querySelectorAll(".gif-container"));

    //Swiper Carousel------------
    var swiper = new Swiper('.swiper-container', {
        effect: 'coverflow',
        grabCursor: true,
        centeredSlides: true,
        slidesPerView: 'auto',
        loop: true,
        loopFillGroupWithBlank: true,
        coverflowEffect: {
            rotate: 30,
            stretch: 0,
            depth: 470,
            modifier: 1,
            slideShadows : true,
        },
        autoplay: {
            delay: 1500,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        }
    });

    //depended select
    var $select1 = $( '#select1' ),
		$select2 = $( '#select2' ),
    $options = $select2.find( 'option' );
    
    $select1.on( 'change', function() {
        $select2.html( $options.filter( '[value="' + this.value + '"]' ) );
    } ).trigger( 'change' );

    //
    $('#leaderboardtb').DataTable({
        responsive: true,
        "language": {
            "lengthMenu": "Display _MENU_ records per page",
            "zeroRecords": "Nothing found - sorry",
            "info": "Showing page _PAGE_ of _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtered from _MAX_ total records)"
        },
        "pagingType": "full_numbers",
        "ordering": false
    });

    $('#registerbtn').on("click", function(){
        $('#RegistrationMd').modal('hide');
        $('#ProfileMd').modal('show');
    });
});